GST File Extractor - Sample Test Folder

This folder contains FAKE / TEST documents only.

Test setup:
- 3 months: April, May, and June 2026
- 6 dated folders
- 12 matching PDFs
- 1 FUEL + 1 STATEMENT in every dated folder
- Unit number: 99999
- Two extra PDFs are included on purpose and should be ignored:
  * _FUELTAX.pdf
  * _REPAIRS.pdf

How to test:
1. Extract this ZIP.
2. For folder mode, choose the Sample_GST_Files folder.
3. For ZIP mode, upload the ZIP directly.
4. The app should auto-detect 3 months and 6 pay periods.
5. Missing periods should be 0.
6. The rename preview should produce names like:
   2026-04_April_01-15_99999_FUEL.pdf
   2026-04_April_01-15_99999_STATEMENT.pdf

All dollar amounts and business information in these PDFs are fictional.
